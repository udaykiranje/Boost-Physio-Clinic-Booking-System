BEGIN TRANSACTION;

-- Table to store all members (patients and physiotherapists)
CREATE TABLE IF NOT EXISTS Members (
    member_id INTEGER PRIMARY KEY AUTOINCREMENT,
    full_name TEXT NOT NULL,
    address TEXT,
    phone TEXT
);

-- Table for patients
CREATE TABLE IF NOT EXISTS Patients (
    patient_id INTEGER PRIMARY KEY,
    FOREIGN KEY(patient_id) REFERENCES Members(member_id)
);

-- Table for physiotherapists
CREATE TABLE IF NOT EXISTS Physiotherapists (
    physio_id INTEGER PRIMARY KEY,
    FOREIGN KEY(physio_id) REFERENCES Members(member_id)
);

-- Table for areas of expertise
CREATE TABLE IF NOT EXISTS Expertise (
    expertise_id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT UNIQUE NOT NULL
);

-- Mapping table: which physiotherapist has which expertise
CREATE TABLE IF NOT EXISTS PhysioExpertise (
    physio_id INTEGER,
    expertise_id INTEGER,
    PRIMARY KEY (physio_id, expertise_id),
    FOREIGN KEY(physio_id) REFERENCES Physiotherapists(physio_id),
    FOREIGN KEY(expertise_id) REFERENCES Expertise(expertise_id)
);

-- Table for treatments
CREATE TABLE IF NOT EXISTS Treatments (
    treatment_id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    expertise_id INTEGER,
    FOREIGN KEY(expertise_id) REFERENCES Expertise(expertise_id)
);

-- Table for appointment slots
CREATE TABLE IF NOT EXISTS Appointments (
    appointment_id INTEGER PRIMARY KEY AUTOINCREMENT,
    physio_id INTEGER,
    treatment_id INTEGER,
    appointment_date TEXT,     -- format: 'YYYY-MM-DD'
    appointment_day TEXT CHECK(appointment_day IN 
        ('Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday')),
    appointment_time TEXT,     -- format: '10:00-11:00', '11:00-12:00', etc.
    FOREIGN KEY(physio_id) REFERENCES Physiotherapists(physio_id),
    FOREIGN KEY(treatment_id) REFERENCES Treatments(treatment_id)
);


-- Table to track which patient booked which appointment
CREATE TABLE IF NOT EXISTS Bookings (
    booking_id INTEGER PRIMARY KEY AUTOINCREMENT,
    appointment_id INTEGER,
    patient_id INTEGER,
    booking_datetime TEXT,  -- format: full date and time of booking
	status TEXT CHECK(status IN ('booked', 'cancelled', 'attended')) DEFAULT 'booked',
    FOREIGN KEY(appointment_id) REFERENCES Appointments(appointment_id),
    FOREIGN KEY(patient_id) REFERENCES Patients(patient_id)
);


-- Physiotherapists (added to Members)
INSERT INTO Members (full_name, address, phone) VALUES 
('Amit Patel', '12 Health Way, London', '+447700900001'),
('Emily Richardson', '45 Wellness Ave, Manchester', '+447700900002'),
('Rajesh Nair', '87 Rehab Rd, Birmingham', '+447700900003'),
('Sophie Bennett', '23 Spine St, Leeds', '+447700900004'),
('Priya Mehta', '66 Therapy Ln, Bristol', '+447700900005');

-- Link to Physiotherapists table using the same IDs
INSERT INTO Physiotherapists (physio_id) VALUES 
(1), (2), (3), (4), (5);


-- Patients (added to Members)
INSERT INTO Members (full_name, address, phone) VALUES 
('Ravi Kumar', '10 Park Rd, London', '+447700900101'),
('Liam Smith', '22 Bridge St, Manchester', '+447700900102'),
('Ananya Sharma', '3 Hill St, Leeds', '+447700900103'),
('Oliver Brown', '5 Garden Rd, Birmingham', '+447700900104'),
('Meera Iyer', '9 Elm St, Liverpool', '+447700900105'),
('Ayaan Hussain', '14 Brook St, Bristol', '+447700900106'),
('Chloe Wilson', '28 Oak Ln, Sheffield', '+447700900107'),
('Kabir Joshi', '31 Maple Ave, Nottingham', '+447700900108'),
('Grace Thompson', '19 Forest Dr, York', '+447700900109'),
('Devika Reddy', '8 River St, Bath', '+447700900110'),
('Ethan Clark', '17 Meadow Rd, Cambridge', '+447700900111'),
('Saanvi Desai', '41 Valley View, Oxford', '+447700900112');

-- Link to Patients table using corresponding member_ids (IDs 6 to 17)
INSERT INTO Patients (patient_id) VALUES 
(6), (7), (8), (9), (10), (11), (12), (13), (14), (15), (16), (17);

INSERT INTO Expertise (name) VALUES 
('Physiotherapy'),
('Osteopathy'),
('Rehabilitation');


-- Assume physio_id 1–5 are:
-- 1: Amit Patel, 2: Emily Richardson, 3: Rajesh Nair, 4: Sophie Bennett, 5: Priya Mehta

INSERT INTO PhysioExpertise (physio_id, expertise_id) VALUES 
(1, 1), -- Amit Patel: Physiotherapy
(1, 3), -- Amit Patel: Rehabilitation

(2, 1), -- Emily Richardson: Physiotherapy
(2, 2), -- Emily Richardson: Osteopathy

(3, 2), -- Rajesh Nair: Osteopathy
(3, 3), -- Rajesh Nair: Rehabilitation

(4, 1), -- Sophie Bennett: Physiotherapy

(5, 1), -- Priya Mehta: Physiotherapy
(5, 3); -- Priya Mehta: Rehabilitation

-- Physiotherapy Treatments
INSERT INTO Treatments (name, expertise_id) VALUES 
('Massage', 1),
('Mobilisation of the spine and joints', 1),
('Neural mobilisation', 1);

-- Osteopathy Treatments
INSERT INTO Treatments (name, expertise_id) VALUES 
('Cranial osteopathy', 2),
('Myofascial release', 2);

-- Rehabilitation Treatments
INSERT INTO Treatments (name, expertise_id) VALUES 
('Pool rehabilitation', 3),
('Post-surgical rehab', 3),
('Balance and coordination therapy', 3);


-- Week 1
INSERT INTO Appointments (physio_id, treatment_id, appointment_date, appointment_day, appointment_time) VALUES
(1, 1, '2025-05-05', 'Monday', '10:00-11:00'),
(1, 3, '2025-05-05', 'Monday', '11:00-12:00'),
(2, 2, '2025-05-06', 'Tuesday', '10:00-11:00'),
(2, 5, '2025-05-06', 'Tuesday', '11:00-12:00'),
(3, 4, '2025-05-07', 'Wednesday', '10:00-11:00'),
(3, 6, '2025-05-07', 'Wednesday', '11:00-12:00'),
(4, 1, '2025-05-08', 'Thursday', '10:00-11:00'),
(4, 2, '2025-05-08', 'Thursday', '11:00-12:00'),
(5, 7, '2025-05-09', 'Friday', '10:00-11:00'),
(5, 8, '2025-05-09', 'Friday', '11:00-12:00');

-- Week 2
INSERT INTO Appointments (physio_id, treatment_id, appointment_date, appointment_day, appointment_time) VALUES
(1, 3, '2025-05-12', 'Monday', '10:00-11:00'),
(1, 7, '2025-05-12', 'Monday', '11:00-12:00'),
(2, 1, '2025-05-13', 'Tuesday', '10:00-11:00'),
(2, 4, '2025-05-13', 'Tuesday', '11:00-12:00'),
(3, 5, '2025-05-14', 'Wednesday', '10:00-11:00'),
(3, 6, '2025-05-14', 'Wednesday', '11:00-12:00'),
(4, 1, '2025-05-15', 'Thursday', '10:00-11:00'),
(4, 8, '2025-05-15', 'Thursday', '11:00-12:00'),
(5, 2, '2025-05-16', 'Friday', '10:00-11:00'),
(5, 6, '2025-05-16', 'Friday', '11:00-12:00');

-- Week 3
INSERT INTO Appointments (physio_id, treatment_id, appointment_date, appointment_day, appointment_time) VALUES
(1, 4, '2025-05-19', 'Monday', '10:00-11:00'),
(1, 5, '2025-05-19', 'Monday', '11:00-12:00'),
(2, 6, '2025-05-20', 'Tuesday', '10:00-11:00'),
(2, 8, '2025-05-20', 'Tuesday', '11:00-12:00'),
(3, 1, '2025-05-21', 'Wednesday', '10:00-11:00'),
(3, 3, '2025-05-21', 'Wednesday', '11:00-12:00'),
(4, 5, '2025-05-22', 'Thursday', '10:00-11:00'),
(4, 6, '2025-05-22', 'Thursday', '11:00-12:00'),
(5, 7, '2025-05-23', 'Friday', '10:00-11:00'),
(5, 2, '2025-05-23', 'Friday', '11:00-12:00');

-- Week 4
INSERT INTO Appointments (physio_id, treatment_id, appointment_date, appointment_day, appointment_time) VALUES
(1, 1, '2025-05-26', 'Monday', '10:00-11:00'),
(1, 6, '2025-05-26', 'Monday', '11:00-12:00'),
(2, 4, '2025-05-27', 'Tuesday', '10:00-11:00'),
(2, 7, '2025-05-27', 'Tuesday', '11:00-12:00'),
(3, 3, '2025-05-28', 'Wednesday', '10:00-11:00'),
(3, 8, '2025-05-28', 'Wednesday', '11:00-12:00'),
(4, 2, '2025-05-29', 'Thursday', '10:00-11:00'),
(4, 3, '2025-05-29', 'Thursday', '11:00-12:00'),
(5, 1, '2025-05-30', 'Friday', '10:00-11:00'),
(5, 4, '2025-05-30', 'Friday', '11:00-12:00');



COMMIT;


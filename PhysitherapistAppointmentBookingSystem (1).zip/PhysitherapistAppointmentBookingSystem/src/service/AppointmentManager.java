/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package service;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import util.DBConnection;


public class AppointmentManager {
    
    private DBConnection dbCon = new DBConnection();
    private JComboBox<String> jComboAreaExpertise,jComboPhysiotherapist,jComboDate, jComboBoxDay, jComboTime;

    private final int patient_id;
    private final int booking_Id;

    public AppointmentManager(JComboBox<String> physiotherapist, JComboBox<String> area_expertise, JComboBox<String> date,
            JComboBox<String> day, JComboBox<String> time, int patientId, int bookingId, int appointmentId) {
        this.jComboAreaExpertise = area_expertise;
        this.jComboPhysiotherapist = physiotherapist ;
         this.jComboDate = date;
        this.jComboBoxDay = day;
        this.jComboTime = time;
        this.patient_id = patientId;
        this.booking_Id = bookingId;
    }

    public void loadCurrentDetails() {
        String sqlStr = "SELECT bo.booking_id, a.appointment_id, m.full_name AS physiotherapist_name, t.name AS treatment_name, a.appointment_day, a.appointment_date, a.appointment_time, bo.booking_datetime FROM Appointments a JOIN Treatments t ON a.treatment_id = t.treatment_id JOIN Physiotherapists p ON a.physio_id = p.physio_id JOIN Members m ON p.physio_id = m.member_id JOIN Bookings bo ON a.appointment_id = bo.appointment_id WHERE bo.patient_id = ? AND bo.booking_id = ?";

        try (Connection con = dbCon.getConnections();
             PreparedStatement pstmt = con.prepareStatement(sqlStr)) {
            pstmt.setInt(1, patient_id);
            pstmt.setInt(2, booking_Id);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                System.out.println("AppointmentManager.loadCurrentDetails: " + rs.getInt("physiotherapist_name"));
                
        
                //jComboBoxGrade.setSelectedItem(String.valueOf(rs.getInt("grade_level")));
                //jComboAreaExpertise.setSelectedItem(String.valueOf(rs.getInt("grade_level")));
                //jComboAreaExpertise.setSelectedItem(rs.getString("physiotherapist_name"));
                //jComboPhysiotherapist.setSelectedItem(rs.getString("physiotherapist_name"));
                //jComboDate.setSelectedItem(rs.getString("appointment_date"));
                //jComboBoxDay.setSelectedItem(rs.getString("appointment_day"));
                //jComboTime.setSelectedItem(rs.getString("appointment_time"));
            }
        } catch (SQLException e) {
            System.out.println("loadCurrentDetails: " + e.getMessage());
        }
    }
    
    public int getPhysiotherapistIdByName(String fullName) {
        
        String sql = "SELECT p.physio_id " +
                     "FROM Members m " +
                     "JOIN Physiotherapists p ON m.member_id = p.physio_id " +
                     "WHERE m.full_name = ?";

        try (Connection con = dbCon.getConnections();
             PreparedStatement pstmt = con.prepareStatement(sql)) {

            pstmt.setString(1, fullName);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                return rs.getInt("physio_id");
            }

        } catch (Exception e) {
            System.out.println("Error retrieving physiotherapist ID: " + e.getMessage());
        }

        return -1; // return -1 if not found or error
    }

    
    public List<String> loadPhysiotherapist(String area_expertise) {
      
         
        List<String> names = new ArrayList<>();
        String full_name = "";
        String sqlString = "SELECT DISTINCT m.full_name FROM Members m JOIN Physiotherapists p ON m.member_id = p.physio_id JOIN PhysioExpertise pe ON p.physio_id = pe.physio_id JOIN Expertise e ON pe.expertise_id = e.expertise_id JOIN Treatments t ON e.expertise_id = t.expertise_id JOIN Appointments a ON p.physio_id = a.physio_id AND a.treatment_id = t.treatment_id LEFT JOIN Bookings b ON a.appointment_id = b.appointment_id AND b.status = 'booked' WHERE e.name = ? AND (b.appointment_id IS NULL)";
        
        try (Connection con = dbCon.getConnections();
            PreparedStatement pstmt = con.prepareStatement(sqlString)) {
            
           pstmt.setString(1, area_expertise);
           
           ResultSet rs = pstmt.executeQuery();

           while (rs.next()) {
               full_name = rs.getString("full_name");
               
               names.add(full_name);
           }

       } catch (Exception e) {
           System.out.println("AppointmentManager.loadPhysiotherapist: " + e.getMessage());
       }

       return names;
    }
    
    public List<String> loadDates(String area_expertise, String physiotherapists) {
        
        //int physio_id = getPhysiotherapistIdByName(physiotherapists);
         
        List<String> dates = new ArrayList<>();
        String date = "";
        String sqlString = "SELECT DISTINCT a.appointment_date " +
                   "FROM Members m " +
                   "JOIN Physiotherapists p ON m.member_id = p.physio_id " +
                   "JOIN PhysioExpertise pe ON p.physio_id = pe.physio_id " +
                   "JOIN Expertise e ON pe.expertise_id = e.expertise_id " +
                   "JOIN Treatments t ON e.expertise_id = t.expertise_id " +
                   "JOIN Appointments a ON p.physio_id = a.physio_id AND a.treatment_id = t.treatment_id " +
                   "LEFT JOIN Bookings b ON a.appointment_id = b.appointment_id AND b.status = 'booked' " +
                   "WHERE e.name = ? AND m.full_name = ? AND b.appointment_id IS NULL " +
                   "ORDER BY a.appointment_date ASC";

        try (Connection con = dbCon.getConnections();
            PreparedStatement pstmt = con.prepareStatement(sqlString)) {
            
           pstmt.setString(1, area_expertise);
           pstmt.setString(2, physiotherapists);
           
           ResultSet rs = pstmt.executeQuery();

           while (rs.next()) {
               date = rs.getString("appointment_date");
               
               dates.add(date);
           }

       } catch (Exception e) {
           System.out.println("AppointmentManager.loadDates: " + e.getMessage());
       }

       return dates;
    }
    
    public List<String> loadDays(String area_expertise, String physiotherapists, String date) {
        
        //int physio_id = getPhysiotherapistIdByName(physiotherapists);
         
        List<String> days = new ArrayList<>();
        String day = "";
        String sqlString = "SELECT DISTINCT a.appointment_day " +
                   "FROM Members m " +
                   "JOIN Physiotherapists p ON m.member_id = p.physio_id " +
                   "JOIN PhysioExpertise pe ON p.physio_id = pe.physio_id " +
                   "JOIN Expertise e ON pe.expertise_id = e.expertise_id " +
                   "JOIN Treatments t ON e.expertise_id = t.expertise_id " +
                   "JOIN Appointments a ON p.physio_id = a.physio_id AND a.treatment_id = t.treatment_id " +
                   "LEFT JOIN Bookings b ON a.appointment_id = b.appointment_id AND b.status = 'booked' " +
                   "WHERE e.name = ? AND m.full_name = ? AND a.appointment_date = ? AND b.appointment_id IS NULL " +
                   "ORDER BY a.appointment_date ASC";

        try (Connection con = dbCon.getConnections();
            PreparedStatement pstmt = con.prepareStatement(sqlString)) {
            
           pstmt.setString(1, area_expertise);
           pstmt.setString(2, physiotherapists);
           pstmt.setString(3, date);
           
           ResultSet rs = pstmt.executeQuery();

           while (rs.next()) {
               day = rs.getString("appointment_day");
               
               days.add(day);
           }

       } catch (Exception e) {
           System.out.println("AppointmentManager.loadDays: " + e.getMessage());
       }

       return days;
    }
    
    public List<String> loadTimes(String area_expertise, String physiotherapists, String date, String day) {
        
        //int physio_id = getPhysiotherapistIdByName(physiotherapists);
         
        List<String> times = new ArrayList<>();
        String time = "";
        String sqlString = "SELECT DISTINCT a.appointment_time " +
                   "FROM Members m " +
                   "JOIN Physiotherapists p ON m.member_id = p.physio_id " +
                   "JOIN PhysioExpertise pe ON p.physio_id = pe.physio_id " +
                   "JOIN Expertise e ON pe.expertise_id = e.expertise_id " +
                   "JOIN Treatments t ON e.expertise_id = t.expertise_id " +
                   "JOIN Appointments a ON p.physio_id = a.physio_id AND a.treatment_id = t.treatment_id " +
                   "LEFT JOIN Bookings b ON a.appointment_id = b.appointment_id AND b.status = 'booked' " +
                   "WHERE e.name = ? AND m.full_name = ? AND a.appointment_date = ? AND a.appointment_day = ? AND b.appointment_id IS NULL " +
                   "ORDER BY a.appointment_date ASC";

        try (Connection con = dbCon.getConnections();
            PreparedStatement pstmt = con.prepareStatement(sqlString)) {
            
           pstmt.setString(1, area_expertise);
           pstmt.setString(2, physiotherapists);
           pstmt.setString(3, date);
           pstmt.setString(4, day);
           
           ResultSet rs = pstmt.executeQuery();

           while (rs.next()) {
               time = rs.getString("appointment_time");
               
               times.add(time);
           }

       } catch (Exception e) {
           System.out.println("AppointmentManager.loadTimes: " + e.getMessage());
       }

       return times;
    }
       
    private int getAppointmentId(String selectedAreaExpertise, String selectedPhysiotherapist, String selectedDate, String selectedDay, String selectedTime) throws SQLException {
        
        String sqlString = "SELECT DISTINCT a.appointment_id " +
                   "FROM Members m " +
                   "JOIN Physiotherapists p ON m.member_id = p.physio_id " +
                   "JOIN PhysioExpertise pe ON p.physio_id = pe.physio_id " +
                   "JOIN Expertise e ON pe.expertise_id = e.expertise_id " +
                   "JOIN Treatments t ON e.expertise_id = t.expertise_id " +
                   "JOIN Appointments a ON p.physio_id = a.physio_id AND a.treatment_id = t.treatment_id " +
                   "LEFT JOIN Bookings b ON a.appointment_id = b.appointment_id AND b.status = 'booked' " +
                   "WHERE e.name = ? AND m.full_name = ? AND a.appointment_date = ? AND a.appointment_day = ? AND a.appointment_time = ? AND b.appointment_id IS NULL " +
                   "ORDER BY a.appointment_date ASC";
        
        try (Connection con = dbCon.getConnections();
             PreparedStatement pstmt = con.prepareStatement(sqlString)) {
            pstmt.setString(1, selectedAreaExpertise);
            pstmt.setString(2, selectedPhysiotherapist);
            pstmt.setString(3, selectedDate);
            pstmt.setString(4, selectedDay);
            pstmt.setString(5, selectedTime);
            
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return rs.getInt("appointment_id");
            }
            throw new SQLException("No appointment found for the specified details.");
        }
    }
    
    public void editBooking() {
        
        String selectedAreaExpertise = (String) jComboAreaExpertise.getSelectedItem();
        String selectedPhysiotherapist = (String) jComboPhysiotherapist.getSelectedItem();
        String selectedDate = (String) jComboDate.getSelectedItem();
        String selectedDay = (String) jComboBoxDay.getSelectedItem();
        String selectedTime = (String) jComboTime.getSelectedItem();

        try {
            int appointment_id = getAppointmentId(selectedAreaExpertise, selectedPhysiotherapist, selectedDate,selectedDay,selectedTime);
            updateBooking(appointment_id, booking_Id);
        } catch (SQLException | NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Failed to update booking: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void updateBooking(int appointment_id, int booking_Id) throws SQLException {
        String sql = "UPDATE Bookings SET appointment_id = ? WHERE booking_id = ?";
        try (Connection con = dbCon.getConnections();
             PreparedStatement pstmt = con.prepareStatement(sql)) {
            pstmt.setInt(1, appointment_id);
            pstmt.setInt(2, booking_Id);
            pstmt.executeUpdate();
            JOptionPane.showMessageDialog(null, "Booking updated successfully", "Success", JOptionPane.INFORMATION_MESSAGE);
        }
    }
    
   
}
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package service;

import model.Treatment;
import util.DBConnection;

import javax.swing.*;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class TreatmentService {
    
    Connection con;
    DBConnection dbCon = new DBConnection();
    
    public List<Treatment> getAvailableTreatments() {
        List<Treatment> treatments = new ArrayList<>();
        String sql = "SELECT a.appointment_id,a.appointment_date, a.appointment_day, a.appointment_time, m.full_name AS physiotherapist, t.name AS treatment, e.name AS area_of_expertise FROM Appointments a JOIN Treatments t ON a.treatment_id = t.treatment_id JOIN Expertise e ON t.expertise_id = e.expertise_id JOIN Physiotherapists p ON a.physio_id = p.physio_id JOIN Members m ON p.physio_id = m.member_id ORDER BY a.appointment_date, a.appointment_time";
        

        try (Connection con = dbCon.getConnections();  
             Statement stmt = con.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                int appointmentId = rs.getInt("appointment_id");
                if (!isAppointmentFull(appointmentId)) {
                    Treatment treatment = new Treatment();
                    treatment.setAppointmentId(appointmentId);
                    treatment.setPhysiotherapistName(rs.getString("physiotherapist"));
                    treatment.setTreatment(rs.getString("treatment"));
                    treatment.setAreaExpertise(rs.getString("area_of_expertise"));
                    treatment.setDate(rs.getString("appointment_date"));
                    treatment.setDay(rs.getString("appointment_day"));
                    treatment.setTime(rs.getString("appointment_time"));
                    
                    

                    treatments.add(treatment);
                }
            }
        } catch (SQLException e) {
            System.out.println("TreatmentService.getAvailableTreatments: " + e.getMessage());
        }
        return treatments;
    }

    public boolean isAppointmentFull(int appointmentId) {
        String sqlBookings = "SELECT COUNT(appointment_id) AS booked_count FROM Bookings WHERE appointment_id = ? AND status = 'booked'";
        int bookedCount = 0;
        int maxCapacity = 1;  

        try (Connection con = dbCon.getConnections(); 
             PreparedStatement stmt = con.prepareStatement(sqlBookings)) {

            stmt.setInt(1, appointmentId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                bookedCount = rs.getInt("booked_count");
            }

            return bookedCount >= maxCapacity;
        } catch (SQLException e) {
            System.out.println("TreatmentService.isAppointmentFull Database error: " + e.getMessage());
            return false;  // Return false if there's a database error
        }
    }
    
    public void bookSelectedTreatment(int patientId, int appointmentId) {
        if (isAppointmentFull(appointmentId)) {
            JOptionPane.showMessageDialog(null, "The treatment is already full");
            return;
        }

        try {
            processBooking(patientId, appointmentId);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "TreatmentService.bookSelectedTreatment Error during booking: " + e.getMessage());
        }
    }

   

    private void processBooking(int patientId, int appointmentId) throws Exception {
       
        if (hasExistingBooking(patientId, appointmentId)) {
            JOptionPane.showMessageDialog(null, "You already booked this treatment.");
            return;
        }

        bookAppointment(patientId, appointmentId);
        
        JOptionPane.showMessageDialog(null, "Appointment booked successfully.");
    }
    
    private boolean hasExistingBooking(int patientId, int appointmentId) {
        String query = "SELECT COUNT(*) AS count FROM Bookings WHERE patient_id = ? AND appointment_id = ?";
        try (Connection con = dbCon.getConnections();
             PreparedStatement pstmt = con.prepareStatement(query)) {
            pstmt.setInt(1, patientId);
            pstmt.setInt(2, appointmentId);
            ResultSet rs = pstmt.executeQuery();
            return rs.next() && rs.getInt("count") > 0;
        } catch (SQLException e) {
            System.out.println("TreatmentService.hasExistingBooking Database error when checking for existing booking: " + e.getMessage());
        }
        return false;
    }

    private void bookAppointment(int patientId, int appointmentId) throws SQLException {
        
        String query = "INSERT INTO Bookings (patient_id, appointment_id, status, booking_datetime) VALUES (?, ?, 'booked', CURRENT_DATE)";
        try (Connection con = dbCon.getConnections();
             PreparedStatement pstmt = con.prepareStatement(query)) {
            pstmt.setInt(1, patientId);
            pstmt.setInt(2, appointmentId);
            pstmt.executeUpdate();
        }
    }

 
    
}

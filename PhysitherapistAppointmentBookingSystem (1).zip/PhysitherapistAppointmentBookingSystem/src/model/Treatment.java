/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;


public class Treatment {
    private int appointmentId;
    private String date;
    private String day;
    private String timeSlot;
    private String area_of_expertise;
    private String treatment_name;
    private String physiotherapistName; // New field for the coach's name

    // Getters and setters for the coach name
    public String getPhysiotherapistName() {
        return physiotherapistName;
    }

    public void setPhysiotherapistName(String physiotherapistName) {
        this.physiotherapistName = physiotherapistName;
    }

    // Existing getters and setters for other fields
    public int getAppointmentId() {
        return appointmentId;
    }

    public void setAppointmentId(int appointmentId) {
        this.appointmentId = appointmentId;
    }
    
    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    
    public String getDay() {
        return day;
    }

    public void setDay(String day) {
        this.day = day;
    }

    public String getTime() {
        return timeSlot;
    }

    public void setTime(String timeSlot) {
        this.timeSlot = timeSlot;
    }

    public String getAreaExpertise() {
        return area_of_expertise;
    }

    public void setAreaExpertise(String area_of_expertise) {
        this.area_of_expertise = area_of_expertise;
    }

    public String getTreatment() {
        return treatment_name;
    }

    public void setTreatment(String treatment_name) {
        this.treatment_name = treatment_name;
    }
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package util;

import java.sql.*;

public class DBConnection {

    public Connection getConnections() throws SQLException {

        Connection con = null;

        try {

            String dbURL = "jdbc:sqlite:D:/PhysitherapistAppointmentBookingSystem zipped File-Report/PhysitherapistAppointmentBookingSystem/db/boost_physio_db.db";

            con = DriverManager.getConnection(dbURL);

            return con;
        } catch (SQLException e) {
            System.out.println(e.getMessage());

            return null;
        }
    }

}

package model;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

import static org.junit.Assert.*;

/**
 * Unit tests for the Treatment model class.
 */
public class TreatmentTest {

    private static Treatment instance;

    @BeforeClass
    public static void setUpClass() {
        instance = new Treatment();
    }

    @AfterClass
    public static void tearDownClass() {
        instance = null;
    }

    @Test
    public void testGetAndSetPhysiotherapistName() {
        System.out.println("getPhysiotherapistName");
        String expected = "Dr. Jane Smith";
        instance.setPhysiotherapistName(expected);
        String result = instance.getPhysiotherapistName();
        assertEquals(expected, result);
    }

    @Test
    public void testGetAndSetAppointmentId() {
        System.out.println("getAppointmentId");
        int expected = 101;
        instance.setAppointmentId(expected);
        int result = instance.getAppointmentId();
        assertEquals(expected, result);
    }

    @Test
    public void testGetAndSetDate() {
        System.out.println("getDate");
        String expected = "2025-04-10";
        instance.setDate(expected);
        String result = instance.getDate();
        assertEquals(expected, result);
    }

    @Test
    public void testGetAndSetDay() {
        System.out.println("getDay");
        String expected = "Thursday";
        instance.setDay(expected);
        String result = instance.getDay();
        assertEquals(expected, result);
    }

    @Test
    public void testGetAndSetTime() {
        System.out.println("getTime");
        String expected = "09:00 - 10:00";
        instance.setTime(expected);
        String result = instance.getTime();
        assertEquals(expected, result);
    }

    @Test
    public void testGetAndSetAreaExpertise() {
        System.out.println("getAreaExpertise");
        String expected = "Rehabilitation";
        instance.setAreaExpertise(expected);
        String result = instance.getAreaExpertise();
        assertEquals(expected, result);
    }

    @Test
    public void testGetAndSetTreatment() {
        System.out.println("getTreatment");
        String expected = "Hydrotherapy";
        instance.setTreatment(expected);
        String result = instance.getTreatment();
        assertEquals(expected, result);
    }
}

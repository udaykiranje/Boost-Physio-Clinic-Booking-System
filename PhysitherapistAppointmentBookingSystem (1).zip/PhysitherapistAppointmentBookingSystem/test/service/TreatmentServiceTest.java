package service;

import model.Treatment;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

import java.util.List;

import static org.junit.Assert.*;

/**
 * Unit tests for the TreatmentService class.
 */
public class TreatmentServiceTest {

    private static TreatmentService instance;

    @BeforeClass
    public static void setUpClass() {
        instance = new TreatmentService();
    }

    @AfterClass
    public static void tearDownClass() {
        instance = null;
    }

    @Test
    public void testGetAvailableTreatments() {
        System.out.println("getAvailableTreatments");
        List<Treatment> result = instance.getAvailableTreatments();
        assertNotNull("Available treatments list should not be null", result);
        assertTrue("Treatment list size should be 0 or more", result.size() >= 0);
    }

    @Test
    public void testIsAppointmentFull() {
        System.out.println("isAppointmentFull");
        int appointmentId = 1; // Use a valid appointment ID from your test DB
        boolean result = instance.isAppointmentFull(appointmentId);
        assertTrue(result == true || result == false); // Should be a valid boolean result
    }

    @Test
    public void testBookSelectedLesson() {
        System.out.println("bookSelectedLesson");

        int patientId = 1;      // Use a valid patient ID from your DB
        int appointmentId = 1;  // Use a valid appointment ID (not already full/booked)

        try {
            instance.bookSelectedTreatment(patientId, appointmentId);
            assertTrue(true); // Test passes if no exception is thrown
        } catch (Exception e) {
            fail("Exception during bookSelectedLesson: " + e.getMessage());
        }
    }
}

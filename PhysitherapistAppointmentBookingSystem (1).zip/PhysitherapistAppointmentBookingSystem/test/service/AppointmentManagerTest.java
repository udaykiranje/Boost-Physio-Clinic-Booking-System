package service;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

import javax.swing.JComboBox;
import java.util.List;

import static org.junit.Assert.*;

/**
 * Unit tests for the AppointmentManager class.
 */
public class AppointmentManagerTest {

    private static AppointmentManager instance;

    @BeforeClass
    public static void setUpClass() {
        // Mocked combo boxes (empty for now, just to satisfy constructor)
        JComboBox<String> physioBox = new JComboBox<>();
        JComboBox<String> areaBox = new JComboBox<>();
        JComboBox<String> dateBox = new JComboBox<>();
        JComboBox<String> dayBox = new JComboBox<>();
        JComboBox<String> timeBox = new JComboBox<>();

        int patientId = 1;  // Use a valid patient ID from your DB
        int bookingId = 1;  // Use a valid booking ID from your DB
        int appointmentId = 1; // Use a valid appointment ID if needed internally

        instance = new AppointmentManager(physioBox, areaBox, dateBox, dayBox, timeBox, patientId, bookingId, appointmentId);
    }

    @AfterClass
    public static void tearDownClass() {
        instance = null;
    }

    @Test
    public void testLoadCurrentDetails() {
        System.out.println("loadCurrentDetails");
        instance.loadCurrentDetails();
        assertTrue(true); // If no exceptions are thrown, test passes
    }

    @Test
    public void testGetPhysiotherapistIdByName() {
        System.out.println("getPhysiotherapistIdByName");
        String fullName = "Dr. Jane Smith";  // Use valid name from your DB
        int result = instance.getPhysiotherapistIdByName(fullName);
        assertTrue(result >= -1); // -1 means not found; otherwise valid ID
    }

    @Test
    public void testLoadPhysiotherapist() {
        System.out.println("loadPhysiotherapist");
        String area_expertise = "Physiotherapy";  // Use valid area
        List<String> result = instance.loadPhysiotherapist(area_expertise);
        assertNotNull(result);
        assertTrue(result.size() >= 0);
    }

    @Test
    public void testLoadDates() {
        System.out.println("loadDates");
        String area_expertise = "Physiotherapy";  // Must match DB entry
        String physiotherapist = "Dr. Jane Smith"; // Must exist
        List<String> result = instance.loadDates(area_expertise, physiotherapist);
        assertNotNull(result);
        assertTrue(result.size() >= 0);
    }

    @Test
    public void testLoadDays() {
        System.out.println("loadDays");
        String area_expertise = "Physiotherapy";  // Must exist
        String physiotherapist = "Dr. Jane Smith"; // Must exist
        String date = "2025-04-10"; // Should exist in appointment records
        List<String> result = instance.loadDays(area_expertise, physiotherapist, date);
        assertNotNull(result);
        assertTrue(result.size() >= 0);
    }

    @Test
    public void testLoadTimes() {
        System.out.println("loadTimes");
        String area_expertise = "Physiotherapy"; // Must exist
        String physiotherapist = "Dr. Jane Smith"; // Must exist
        String date = "2025-04-10"; // Must exist
        String day = "Monday"; // Match with date in DB
        List<String> result = instance.loadTimes(area_expertise, physiotherapist, date, day);
        assertNotNull(result);
        assertTrue(result.size() >= 0);
    }

    @Test
    public void testEditBooking() {
        System.out.println("editBooking");
        try {
            instance.editBooking();
            assertTrue(true); // If no exception thrown, test passes
        } catch (Exception e) {
            fail("editBooking threw an exception: " + e.getMessage());
        }
    }
}
